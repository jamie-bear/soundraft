import { useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { useAuthStore } from './stores/authStore'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Register from './pages/Register'
import TrackDetail from './pages/TrackDetail'
import PlaylistDetail from './pages/PlaylistDetail'

function App() {
  const checkAuth = useAuthStore((state) => state.checkAuth)

  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      {/* Public shared views */}
      <Route path="/s/track/:token" element={<TrackDetail shared />} />
      <Route path="/s/playlist/:token" element={<PlaylistDetail shared />} />

      {/* Protected routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="tracks/:id" element={<TrackDetail />} />
        <Route path="playlists/:id" element={<PlaylistDetail />} />
      </Route>
    </Routes>
  )
}

export default App
