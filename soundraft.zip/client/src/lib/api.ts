const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api'

interface RequestOptions extends RequestInit {
  auth?: boolean
}

class ApiError extends Error {
  status: number
  
  constructor(message: string, status: number) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
}

async function request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { auth = true, ...fetchOptions } = options
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...fetchOptions.headers,
  }

  // Add auth token if required
  if (auth) {
    const token = localStorage.getItem('token')
    if (token) {
      (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`
    }
  }

  const response = await fetch(`${API_URL}${endpoint}`, {
    ...fetchOptions,
    headers,
  })

  // Handle non-JSON responses
  const contentType = response.headers.get('content-type')
  if (!contentType || !contentType.includes('application/json')) {
    if (!response.ok) {
      throw new ApiError('Request failed', response.status)
    }
    return {} as T
  }

  const data = await response.json()

  if (!response.ok) {
    throw new ApiError(data.error || 'Request failed', response.status)
  }

  return data
}

// Auth API
export const authApi = {
  login: (email: string, password: string) =>
    request<{ user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
      auth: false,
    }),

  register: (email: string, password: string) =>
    request<{ user: User; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
      auth: false,
    }),

  me: () => request<{ user: User }>('/auth/me'),
}

// Tracks API
export const tracksApi = {
  list: () => request<{ tracks: Track[] }>('/tracks'),

  get: (id: string, token?: string) =>
    request<{ track: Track; isOwner: boolean }>(
      `/tracks/${id}${token ? `?token=${token}` : ''}`,
      { auth: !token }
    ),

  create: (data: { title: string; status?: string; type?: string }) =>
    request<{ track: Track }>('/tracks', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Track>) =>
    request<{ track: Track }>(`/tracks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/tracks/${id}`, { method: 'DELETE' }),

  getVersions: (id: string) =>
    request<{ versions: TrackVersion[] }>(`/tracks/${id}/versions`),

  uploadVersion: async (id: string, file: File) => {
    const formData = new FormData()
    formData.append('audio', file)

    const token = localStorage.getItem('token')
    const response = await fetch(`${API_URL}/tracks/${id}/versions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    const data = await response.json()
    if (!response.ok) {
      throw new ApiError(data.error || 'Upload failed', response.status)
    }
    return data as { version: TrackVersion }
  },

  share: (id: string, makePublic: boolean) =>
    request<{ shareToken: string; releaseStatus: string }>(`/tracks/${id}/share`, {
      method: 'POST',
      body: JSON.stringify({ makePublic }),
    }),
}

// Playlists API
export const playlistsApi = {
  list: () => request<{ playlists: Playlist[] }>('/playlists'),

  get: (id: string, token?: string) =>
    request<{ playlist: Playlist; tracks: Track[]; isOwner: boolean }>(
      `/playlists/${id}${token ? `?token=${token}` : ''}`,
      { auth: !token }
    ),

  create: (data: { title: string; type?: string }) =>
    request<{ playlist: Playlist }>('/playlists', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Playlist>) =>
    request<{ playlist: Playlist }>(`/playlists/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/playlists/${id}`, { method: 'DELETE' }),

  addTrack: (id: string, trackId: string) =>
    request<{ success: boolean }>(`/playlists/${id}/tracks`, {
      method: 'POST',
      body: JSON.stringify({ trackId }),
    }),

  removeTrack: (id: string, trackId: string) =>
    request<{ success: boolean }>(`/playlists/${id}/tracks/${trackId}`, {
      method: 'DELETE',
    }),

  reorder: (id: string, trackIds: string[]) =>
    request<{ success: boolean }>(`/playlists/${id}/reorder`, {
      method: 'PUT',
      body: JSON.stringify({ trackIds }),
    }),

  duplicate: (id: string) =>
    request<{ playlist: Playlist }>(`/playlists/${id}/duplicate`, {
      method: 'POST',
    }),
}

// Comments API
export const commentsApi = {
  list: (trackId: string, token?: string) =>
    request<{ comments: Comment[] }>(
      `/comments/track/${trackId}${token ? `?token=${token}` : ''}`,
      { auth: !token }
    ),

  create: (trackId: string, body: string, audioTimestamp?: number, token?: string) =>
    request<{ comment: Comment }>(`/comments/track/${trackId}`, {
      method: 'POST',
      body: JSON.stringify({ body, audioTimestamp, token }),
      auth: !token,
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/comments/${id}`, { method: 'DELETE' }),
}

// Attachments API
export const attachmentsApi = {
  list: (trackId: string) =>
    request<{ attachments: Attachment[] }>(`/attachments/track/${trackId}`),

  upload: async (trackId: string, file: File) => {
    const formData = new FormData()
    formData.append('file', file)

    const token = localStorage.getItem('token')
    const response = await fetch(`${API_URL}/attachments/track/${trackId}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    const data = await response.json()
    if (!response.ok) {
      throw new ApiError(data.error || 'Upload failed', response.status)
    }
    return data as { attachment: Attachment }
  },

  getDownloadUrl: (id: string) => {
    const token = localStorage.getItem('token')
    return `${API_URL}/attachments/${id}/download?auth=${token}`
  },

  delete: (id: string) =>
    request<{ success: boolean }>(`/attachments/${id}`, { method: 'DELETE' }),
}

// Types
export interface User {
  id: string
  email: string
  role: 'USER' | 'ADMIN'
  created_at?: string
}

export interface Track {
  id: string
  owner_id: string
  title: string
  status: 'POC' | 'DRAFT' | 'WIP' | 'FINAL'
  type: 'RELEASE' | 'RADIO_MIX' | 'ALT_MIX'
  release_status: 'PRIVATE' | 'PUBLIC'
  cover_art_path?: string
  current_version_id?: string
  share_token?: string
  duration_seconds?: number
  current_version_number?: number
  created_at: string
  updated_at: string
}

export interface TrackVersion {
  id: string
  track_id: string
  version_number: number
  filename: string
  storage_key: string
  mime_type: string
  size_bytes: number
  duration_seconds: number
  created_at: string
}

export interface Playlist {
  id: string
  owner_id: string
  title: string
  type: 'ALBUM' | 'EP' | 'SINGLE' | 'PLAYLIST'
  cover_art_path?: string
  is_public: boolean
  share_token?: string
  track_count?: number
  created_at: string
}

export interface Comment {
  id: string
  user_id?: string
  user_email?: string
  track_id: string
  body: string
  audio_timestamp?: number
  created_at: string
}

export interface Attachment {
  id: string
  track_id: string
  filename: string
  size_bytes: number
  created_at: string
}

export { ApiError }
