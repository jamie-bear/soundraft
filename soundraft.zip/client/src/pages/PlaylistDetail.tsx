import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { playlistsApi, Playlist, Track } from '../lib/api'
import { usePlayerStore } from '../stores/playerStore'

interface PlaylistDetailProps {
  shared?: boolean
}

interface SortableTrackProps {
  track: Track & { sort_order: number }
  isOwner: boolean
  onPlay: (track: Track) => void
  currentTrackId?: string
  isPlaying: boolean
}

function SortableTrack({ track, isOwner, onPlay, currentTrackId, isPlaying }: SortableTrackProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: track.id, disabled: !isOwner })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const isCurrentTrack = currentTrackId === track.id

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`flex items-center gap-4 rounded-lg border p-4 ${
        isCurrentTrack
          ? 'border-primary-500/50 bg-primary-500/10'
          : 'border-surface-800 bg-surface-900'
      }`}
    >
      {isOwner && (
        <button
          {...attributes}
          {...listeners}
          className="cursor-grab text-surface-500 hover:text-surface-300 active:cursor-grabbing"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16" />
          </svg>
        </button>
      )}

      <button
        onClick={() => onPlay(track)}
        disabled={!track.current_version_id}
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-surface-800 text-white hover:bg-surface-700 disabled:opacity-50 transition-colors"
      >
        {isCurrentTrack && isPlaying ? (
          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
            <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
          </svg>
        ) : (
          <svg className="h-4 w-4 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z" />
          </svg>
        )}
      </button>

      <div className="min-w-0 flex-1">
        <p className="truncate font-medium text-white">{track.title}</p>
        <p className="text-sm text-surface-400">
          {track.duration_seconds
            ? `${Math.floor(track.duration_seconds / 60)}:${(track.duration_seconds % 60).toString().padStart(2, '0')}`
            : '--:--'}
        </p>
      </div>

      <span className="text-sm text-surface-500">{track.sort_order + 1}</span>
    </div>
  )
}

export default function PlaylistDetail({ shared = false }: PlaylistDetailProps) {
  const { id, token } = useParams<{ id?: string; token?: string }>()
  const playTrack = usePlayerStore((state) => state.playTrack)
  const currentTrack = usePlayerStore((state) => state.currentTrack)
  const isPlaying = usePlayerStore((state) => state.isPlaying)
  const togglePlay = usePlayerStore((state) => state.togglePlay)

  const [playlist, setPlaylist] = useState<Playlist | null>(null)
  const [tracks, setTracks] = useState<(Track & { sort_order: number })[]>([])
  const [isOwner, setIsOwner] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const playlistId = shared ? undefined : id
  const shareToken = shared ? token : undefined

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  useEffect(() => {
    loadPlaylist()
  }, [playlistId, shareToken])

  const loadPlaylist = async () => {
    try {
      setLoading(true)
      const identifier = playlistId || shareToken
      if (!identifier) return

      const { playlist: playlistData, tracks: tracksData, isOwner: owner } = await playlistsApi.get(
        identifier,
        shareToken
      )
      setPlaylist(playlistData)
      setTracks(tracksData.map((t, i) => ({ ...t, sort_order: i })))
      setIsOwner(owner)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load playlist')
    } finally {
      setLoading(false)
    }
  }

  const handlePlay = (track: Track) => {
    if (!track.current_version_id) return

    const isCurrentTrack = currentTrack?.id === track.id

    if (isCurrentTrack) {
      togglePlay()
    } else {
      playTrack({
        id: track.id,
        title: track.title,
        versionId: track.current_version_id,
        version: 1,
        duration: track.duration_seconds || 0,
      })
    }
  }

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event

    if (!over || active.id === over.id || !playlist) return

    const oldIndex = tracks.findIndex((t) => t.id === active.id)
    const newIndex = tracks.findIndex((t) => t.id === over.id)

    const newTracks = arrayMove(tracks, oldIndex, newIndex).map((t, i) => ({
      ...t,
      sort_order: i,
    }))

    setTracks(newTracks)

    try {
      await playlistsApi.reorder(
        playlist.id,
        newTracks.map((t) => t.id)
      )
    } catch (err) {
      // Revert on error
      loadPlaylist()
      setError(err instanceof Error ? err.message : 'Failed to reorder')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
      </div>
    )
  }

  if (error || !playlist) {
    return (
      <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-4 text-red-400">
        {error || 'Playlist not found'}
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-3xl">
      {/* Playlist Header */}
      <div className="mb-8 flex gap-6">
        <div className="h-40 w-40 shrink-0 rounded-xl bg-surface-800">
          {playlist.cover_art_path ? (
            <img src={playlist.cover_art_path} alt="" className="h-full w-full rounded-xl object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <svg className="h-12 w-12 text-surface-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
          )}
        </div>

        <div>
          <p className="mb-1 text-sm font-medium uppercase text-surface-400">{playlist.type}</p>
          <h1 className="mb-2 text-3xl font-bold text-white">{playlist.title}</h1>
          <p className="text-surface-400">{tracks.length} tracks</p>

          {isOwner && (
            <div className="mt-4 flex gap-2">
              <button
                onClick={async () => {
                  try {
                    await playlistsApi.duplicate(playlist.id)
                    // Could navigate to new playlist
                  } catch (err) {
                    setError(err instanceof Error ? err.message : 'Failed to duplicate')
                  }
                }}
                className="rounded-lg bg-surface-800 px-3 py-2 text-sm font-medium text-white hover:bg-surface-700 transition-colors"
              >
                Duplicate
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tracks List */}
      {tracks.length === 0 ? (
        <div className="rounded-xl border border-dashed border-surface-700 bg-surface-900/50 p-12 text-center">
          <p className="text-surface-500">No tracks in this playlist</p>
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={tracks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">
              {tracks.map((track) => (
                <SortableTrack
                  key={track.id}
                  track={track}
                  isOwner={isOwner}
                  onPlay={handlePlay}
                  currentTrackId={currentTrack?.id}
                  isPlaying={isPlaying}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  )
}
