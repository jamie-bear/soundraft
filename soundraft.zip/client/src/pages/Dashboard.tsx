import { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { tracksApi, playlistsApi, Track, Playlist } from '../lib/api'
import { usePlayerStore } from '../stores/playerStore'

const statusColors: Record<string, string> = {
  POC: 'bg-purple-500/20 text-purple-400',
  DRAFT: 'bg-orange-500/20 text-orange-400',
  WIP: 'bg-yellow-500/20 text-yellow-400',
  FINAL: 'bg-green-500/20 text-green-400',
}

export default function Dashboard() {
  const [tracks, setTracks] = useState<Track[]>([])
  const [playlists, setPlaylists] = useState<Playlist[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreateTrack, setShowCreateTrack] = useState(false)
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [creating, setCreating] = useState(false)
  
  const playTrack = usePlayerStore((state) => state.playTrack)
  const currentTrack = usePlayerStore((state) => state.currentTrack)
  const isPlaying = usePlayerStore((state) => state.isPlaying)
  const togglePlay = usePlayerStore((state) => state.togglePlay)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const [tracksRes, playlistsRes] = await Promise.all([
        tracksApi.list(),
        playlistsApi.list(),
      ])
      setTracks(tracksRes.tracks)
      setPlaylists(playlistsRes.playlists)
    } catch (err) {
      console.error('Failed to load data:', err)
    } finally {
      setLoading(false)
    }
  }

  const handlePlay = (track: Track, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    if (!track.current_version_id) return

    const isCurrentTrack = currentTrack?.id === track.id

    if (isCurrentTrack) {
      togglePlay()
    } else {
      playTrack({
        id: track.id,
        title: track.title,
        versionId: track.current_version_id,
        version: track.current_version_number || 1,
        duration: track.duration_seconds || 0,
      })
    }
  }

  const handleCreateTrack = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newTitle.trim()) return

    try {
      setCreating(true)
      await tracksApi.create({ title: newTitle })
      setNewTitle('')
      setShowCreateTrack(false)
      loadData()
    } catch (err) {
      console.error('Failed to create track:', err)
    } finally {
      setCreating(false)
    }
  }

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newTitle.trim()) return

    try {
      setCreating(true)
      await playlistsApi.create({ title: newTitle })
      setNewTitle('')
      setShowCreatePlaylist(false)
      loadData()
    } catch (err) {
      console.error('Failed to create playlist:', err)
    } finally {
      setCreating(false)
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-surface-400">Manage your tracks and playlists</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowCreatePlaylist(true)}
            className="flex items-center gap-2 rounded-lg bg-surface-800 px-4 py-2 text-sm font-medium text-white hover:bg-surface-700 transition-colors"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Playlist
          </button>
          <button
            onClick={() => setShowCreateTrack(true)}
            className="flex items-center gap-2 rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 transition-colors"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Track
          </button>
        </div>
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
        </div>
      ) : (
        <>
          {/* Tracks Section */}
          <section className="mb-12">
            <h2 className="mb-4 text-lg font-semibold text-white">Recent Tracks</h2>
            
            {tracks.length === 0 ? (
              <div className="rounded-xl border border-dashed border-surface-700 bg-surface-900/50 p-8 text-center">
                <p className="mb-4 text-surface-400">No tracks yet</p>
                <button
                  onClick={() => setShowCreateTrack(true)}
                  className="inline-flex items-center gap-2 rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 transition-colors"
                >
                  Create your first track
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {tracks.map((track) => {
                  const isCurrentlyPlaying = currentTrack?.id === track.id && isPlaying
                  
                  return (
                    <Link
                      key={track.id}
                      to={`/tracks/${track.id}`}
                      className="group rounded-xl border border-surface-800 bg-surface-900 p-4 hover:border-surface-700 transition-colors"
                    >
                      {/* Cover art placeholder */}
                      <div className="relative mb-4 aspect-square rounded-lg bg-surface-800">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <svg className="h-12 w-12 text-surface-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                          </svg>
                        </div>
                        
                        {/* Play button overlay */}
                        {track.current_version_id && (
                          <button
                            onClick={(e) => handlePlay(track, e)}
                            className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                          >
                            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-600 text-white">
                              {isCurrentlyPlaying ? (
                                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                                </svg>
                              ) : (
                                <svg className="h-6 w-6 ml-1" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M8 5v14l11-7z" />
                                </svg>
                              )}
                            </div>
                          </button>
                        )}
                      </div>

                      {/* Track info */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h3 className="truncate font-medium text-white">{track.title}</h3>
                          <p className="text-sm text-surface-400">
                            {track.current_version_number ? `v${track.current_version_number}` : 'No versions'}
                          </p>
                        </div>
                        <span className={`shrink-0 rounded-full px-2 py-1 text-xs font-medium ${statusColors[track.status] || 'bg-surface-700 text-surface-300'}`}>
                          {track.status}
                        </span>
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </section>

          {/* Playlists Section */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-white">Playlists</h2>
            
            {playlists.length === 0 ? (
              <div className="rounded-xl border border-dashed border-surface-700 bg-surface-900/50 p-8 text-center">
                <p className="mb-4 text-surface-400">No playlists yet</p>
                <button
                  onClick={() => setShowCreatePlaylist(true)}
                  className="inline-flex items-center gap-2 rounded-lg bg-surface-800 px-4 py-2 text-sm font-medium text-white hover:bg-surface-700 transition-colors"
                >
                  Create your first playlist
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {playlists.map((playlist) => (
                  <Link
                    key={playlist.id}
                    to={`/playlists/${playlist.id}`}
                    className="rounded-xl border border-surface-800 bg-surface-900 p-4 hover:border-surface-700 transition-colors"
                  >
                    <div className="mb-4 aspect-square rounded-lg bg-surface-800">
                      <div className="flex h-full w-full items-center justify-center">
                        <svg className="h-12 w-12 text-surface-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                      </div>
                    </div>
                    <h3 className="truncate font-medium text-white">{playlist.title}</h3>
                    <p className="text-sm text-surface-400">
                      {playlist.track_count || 0} tracks - {playlist.type}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </section>
        </>
      )}

      {/* Create Track Modal */}
      {showCreateTrack && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl border border-surface-800 bg-surface-900 p-6">
            <h2 className="mb-4 text-lg font-semibold text-white">Create New Track</h2>
            <form onSubmit={handleCreateTrack}>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Track title"
                className="mb-4 w-full rounded-lg border border-surface-700 bg-surface-800 px-3 py-2 text-white placeholder-surface-500 focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTrack(false)}
                  className="rounded-lg px-4 py-2 text-sm font-medium text-surface-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || !newTitle.trim()}
                  className="rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50 transition-colors"
                >
                  {creating ? 'Creating...' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreatePlaylist && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl border border-surface-800 bg-surface-900 p-6">
            <h2 className="mb-4 text-lg font-semibold text-white">Create New Playlist</h2>
            <form onSubmit={handleCreatePlaylist}>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Playlist title"
                className="mb-4 w-full rounded-lg border border-surface-700 bg-surface-800 px-3 py-2 text-white placeholder-surface-500 focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreatePlaylist(false)}
                  className="rounded-lg px-4 py-2 text-sm font-medium text-surface-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || !newTitle.trim()}
                  className="rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50 transition-colors"
                >
                  {creating ? 'Creating...' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
