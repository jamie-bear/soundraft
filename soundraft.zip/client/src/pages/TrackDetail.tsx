import { useState, useEffect, useRef } from 'react'
import { useParams } from 'react-router-dom'
import { tracksApi, commentsApi, attachmentsApi, Track, TrackVersion, Comment, Attachment } from '../lib/api'
import { usePlayerStore } from '../stores/playerStore'

interface TrackDetailProps {
  shared?: boolean
}

const statusColors: Record<string, string> = {
  POC: 'bg-purple-500/20 text-purple-400',
  DRAFT: 'bg-orange-500/20 text-orange-400',
  WIP: 'bg-yellow-500/20 text-yellow-400',
  FINAL: 'bg-green-500/20 text-green-400',
}

export default function TrackDetail({ shared = false }: TrackDetailProps) {
  const { id, token } = useParams<{ id?: string; token?: string }>()
  const playTrack = usePlayerStore((state) => state.playTrack)
  const currentTrack = usePlayerStore((state) => state.currentTrack)
  const isPlaying = usePlayerStore((state) => state.isPlaying)
  const togglePlay = usePlayerStore((state) => state.togglePlay)
  
  const [track, setTrack] = useState<Track | null>(null)
  const [versions, setVersions] = useState<TrackVersion[]>([])
  const [comments, setComments] = useState<Comment[]>([])
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [isOwner, setIsOwner] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [activeTab, setActiveTab] = useState<'comments' | 'versions' | 'attachments'>('comments')
  const [newComment, setNewComment] = useState('')
  
  const fileInputRef = useRef<HTMLInputElement>(null)

  const trackId = shared ? undefined : id
  const shareToken = shared ? token : undefined

  useEffect(() => {
    loadTrack()
  }, [trackId, shareToken])

  const loadTrack = async () => {
    try {
      setLoading(true)
      
      // For shared tracks, we need to use the token to get the track
      // The API will look up the track by share_token
      const identifier = trackId || shareToken
      if (!identifier) return

      const { track: trackData, isOwner: owner } = await tracksApi.get(identifier, shareToken)
      setTrack(trackData)
      setIsOwner(owner)

      // Load comments
      const { comments: commentsData } = await commentsApi.list(trackData.id, shareToken)
      setComments(commentsData)

      // Load versions and attachments only for owner
      if (owner) {
        const { versions: versionsData } = await tracksApi.getVersions(trackData.id)
        setVersions(versionsData)

        const { attachments: attachmentsData } = await attachmentsApi.list(trackData.id)
        setAttachments(attachmentsData)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load track')
    } finally {
      setLoading(false)
    }
  }

  const handlePlay = () => {
    if (!track || !track.current_version_id) return

    const isCurrentTrack = currentTrack?.id === track.id
    
    if (isCurrentTrack) {
      togglePlay()
    } else {
      playTrack({
        id: track.id,
        title: track.title,
        versionId: track.current_version_id,
        version: track.current_version_number || 1,
        duration: track.duration_seconds || 0,
      })
    }
  }

  const handleVersionUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !track) return

    try {
      await tracksApi.uploadVersion(track.id, file)
      loadTrack() // Reload to get new version
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed')
    }
  }

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!track || !newComment.trim()) return

    try {
      const progress = usePlayerStore.getState().progress
      const duration = track.duration_seconds || 0
      const audioTimestamp = currentTrack?.id === track.id ? progress * duration : undefined
      
      const { comment } = await commentsApi.create(track.id, newComment, audioTimestamp, shareToken)
      setComments([...comments, comment])
      setNewComment('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add comment')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
      </div>
    )
  }

  if (error || !track) {
    return (
      <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-4 text-red-400">
        {error || 'Track not found'}
      </div>
    )
  }

  const isCurrentlyPlaying = currentTrack?.id === track.id && isPlaying

  return (
    <div className="mx-auto max-w-4xl">
      {/* Track Header */}
      <div className="mb-8 flex gap-6">
        {/* Cover Art */}
        <div className="relative h-48 w-48 shrink-0 rounded-xl bg-surface-800">
          {track.cover_art_path ? (
            <img src={track.cover_art_path} alt="" className="h-full w-full rounded-xl object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <svg className="h-16 w-16 text-surface-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
            </div>
          )}
          
          {/* Play button overlay */}
          <button
            onClick={handlePlay}
            disabled={!track.current_version_id}
            className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity rounded-xl"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary-600 text-white">
              {isCurrentlyPlaying ? (
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                </svg>
              ) : (
                <svg className="h-6 w-6 ml-1" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </div>
          </button>
        </div>

        {/* Track Info */}
        <div className="flex-1">
          <div className="mb-2 flex items-center gap-3">
            <span className={`rounded-full px-2 py-1 text-xs font-medium ${statusColors[track.status] || 'bg-surface-700 text-surface-300'}`}>
              {track.status}
            </span>
            <span className="text-sm text-surface-400">{track.type}</span>
          </div>
          
          <h1 className="mb-2 text-3xl font-bold text-white">{track.title}</h1>
          
          <p className="text-surface-400">
            Version {track.current_version_number || 1}
            {track.duration_seconds && ` - ${Math.floor(track.duration_seconds / 60)}:${(track.duration_seconds % 60).toString().padStart(2, '0')}`}
          </p>

          {isOwner && (
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 rounded-lg bg-surface-800 px-3 py-2 text-sm font-medium text-white hover:bg-surface-700 transition-colors"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                Upload New Version
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*"
                onChange={handleVersionUpload}
                className="hidden"
              />
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex border-b border-surface-800">
        <button
          onClick={() => setActiveTab('comments')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'comments'
              ? 'border-b-2 border-primary-500 text-primary-400'
              : 'text-surface-400 hover:text-white'
          }`}
        >
          Comments ({comments.length})
        </button>
        
        {isOwner && (
          <>
            <button
              onClick={() => setActiveTab('versions')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                activeTab === 'versions'
                  ? 'border-b-2 border-primary-500 text-primary-400'
                  : 'text-surface-400 hover:text-white'
              }`}
            >
              Versions ({versions.length})
            </button>
            <button
              onClick={() => setActiveTab('attachments')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                activeTab === 'attachments'
                  ? 'border-b-2 border-primary-500 text-primary-400'
                  : 'text-surface-400 hover:text-white'
              }`}
            >
              Attachments ({attachments.length})
            </button>
          </>
        )}
      </div>

      {/* Tab Content */}
      {activeTab === 'comments' && (
        <div className="space-y-4">
          {/* Add comment form */}
          <form onSubmit={handleAddComment} className="flex gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 rounded-lg border border-surface-700 bg-surface-800 px-3 py-2 text-white placeholder-surface-500 focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
            />
            <button
              type="submit"
              disabled={!newComment.trim()}
              className="rounded-lg bg-primary-600 px-4 py-2 font-medium text-white hover:bg-primary-700 disabled:opacity-50 transition-colors"
            >
              Post
            </button>
          </form>

          {/* Comments list */}
          {comments.length === 0 ? (
            <p className="py-8 text-center text-surface-500">No comments yet</p>
          ) : (
            <div className="space-y-3">
              {comments.map((comment) => (
                <div key={comment.id} className="rounded-lg border border-surface-800 bg-surface-900 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-medium text-white">{comment.user_email}</span>
                    <div className="flex items-center gap-2 text-xs text-surface-500">
                      {comment.audio_timestamp !== null && (
                        <button 
                          onClick={() => {
                            // Seek to timestamp
                            if (track.current_version_id && track.duration_seconds) {
                              const progress = comment.audio_timestamp! / track.duration_seconds
                              usePlayerStore.getState().seek(progress)
                            }
                          }}
                          className="text-primary-400 hover:text-primary-300"
                        >
                          @{Math.floor(comment.audio_timestamp / 60)}:{Math.floor(comment.audio_timestamp % 60).toString().padStart(2, '0')}
                        </button>
                      )}
                      <span>{new Date(comment.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <p className="text-surface-300">{comment.body}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'versions' && isOwner && (
        <div className="space-y-2">
          {versions.map((version) => (
            <div
              key={version.id}
              className={`flex items-center justify-between rounded-lg border p-4 ${
                version.id === track.current_version_id
                  ? 'border-primary-500/50 bg-primary-500/10'
                  : 'border-surface-800 bg-surface-900'
              }`}
            >
              <div>
                <p className="font-medium text-white">Version {version.version_number}</p>
                <p className="text-sm text-surface-400">{version.filename}</p>
              </div>
              <div className="text-right text-sm text-surface-400">
                <p>{(version.size_bytes / (1024 * 1024)).toFixed(1)} MB</p>
                <p>{new Date(version.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'attachments' && isOwner && (
        <div className="space-y-2">
          {attachments.length === 0 ? (
            <p className="py-8 text-center text-surface-500">No attachments</p>
          ) : (
            attachments.map((attachment) => (
              <div
                key={attachment.id}
                className="flex items-center justify-between rounded-lg border border-surface-800 bg-surface-900 p-4"
              >
                <div>
                  <p className="font-medium text-white">{attachment.filename}</p>
                  <p className="text-sm text-surface-400">
                    {(attachment.size_bytes / 1024).toFixed(1)} KB
                  </p>
                </div>
                <a
                  href={attachmentsApi.getDownloadUrl(attachment.id)}
                  className="rounded-lg bg-surface-800 px-3 py-1.5 text-sm font-medium text-white hover:bg-surface-700 transition-colors"
                >
                  Download
                </a>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}
