const express = require('express');
const bcrypt = require('bcrypt');
const { generateToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

module.exports = function(pool) {
    /**
     * POST /api/auth/register
     * Create a new user account
     */
    router.post('/register', async (req, res) => {
        try {
            const { email, password } = req.body;

            // Validation
            if (!email || !password) {
                return res.status(400).json({ error: 'Email and password are required' });
            }

            if (password.length < 6) {
                return res.status(400).json({ error: 'Password must be at least 6 characters' });
            }

            // Check if user exists
            const existing = await pool.query(
                'SELECT id FROM users WHERE email = $1',
                [email.toLowerCase()]
            );

            if (existing.rows.length > 0) {
                return res.status(409).json({ error: 'Email already registered' });
            }

            // Hash password and create user
            const passwordHash = await bcrypt.hash(password, 10);
            
            const result = await pool.query(
                'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email, role, created_at',
                [email.toLowerCase(), passwordHash]
            );

            const user = result.rows[0];
            const token = generateToken(user);

            res.status(201).json({
                user: {
                    id: user.id,
                    email: user.email,
                    role: user.role
                },
                token
            });
        } catch (err) {
            console.error('Registration error:', err);
            res.status(500).json({ error: 'Registration failed' });
        }
    });

    /**
     * POST /api/auth/login
     * Authenticate user and return JWT
     */
    router.post('/login', async (req, res) => {
        try {
            const { email, password } = req.body;

            // Validation
            if (!email || !password) {
                return res.status(400).json({ error: 'Email and password are required' });
            }

            // Find user
            const result = await pool.query(
                'SELECT id, email, password_hash, role FROM users WHERE email = $1',
                [email.toLowerCase()]
            );

            if (result.rows.length === 0) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            const user = result.rows[0];

            // Verify password
            const validPassword = await bcrypt.compare(password, user.password_hash);
            
            if (!validPassword) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            const token = generateToken(user);

            res.json({
                user: {
                    id: user.id,
                    email: user.email,
                    role: user.role
                },
                token
            });
        } catch (err) {
            console.error('Login error:', err);
            res.status(500).json({ error: 'Login failed' });
        }
    });

    /**
     * GET /api/auth/me
     * Get current user info
     */
    router.get('/me', requireAuth, async (req, res) => {
        try {
            const result = await pool.query(
                'SELECT id, email, role, created_at FROM users WHERE id = $1',
                [req.user.id]
            );

            if (result.rows.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({ user: result.rows[0] });
        } catch (err) {
            console.error('Get user error:', err);
            res.status(500).json({ error: 'Failed to get user' });
        }
    });

    return router;
};
