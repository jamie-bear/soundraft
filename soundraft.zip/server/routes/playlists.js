const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

module.exports = function(pool) {
    
    /**
     * GET /api/playlists
     * List all playlists for authenticated user
     */
    router.get('/', requireAuth, async (req, res) => {
        try {
            const result = await pool.query(`
                SELECT p.*, 
                       COUNT(pt.track_id) as track_count
                FROM playlists p
                LEFT JOIN playlist_tracks pt ON p.id = pt.playlist_id
                WHERE p.owner_id = $1
                GROUP BY p.id
                ORDER BY p.created_at DESC
            `, [req.user.id]);

            res.json({ playlists: result.rows });
        } catch (err) {
            console.error('List playlists error:', err);
            res.status(500).json({ error: 'Failed to list playlists' });
        }
    });

    /**
     * POST /api/playlists
     * Create a new playlist
     */
    router.post('/', requireAuth, async (req, res) => {
        try {
            const { title, type = 'PLAYLIST' } = req.body;

            if (!title) {
                return res.status(400).json({ error: 'Title is required' });
            }

            const shareToken = uuidv4().replace(/-/g, '');

            const result = await pool.query(`
                INSERT INTO playlists (owner_id, title, type, share_token)
                VALUES ($1, $2, $3, $4)
                RETURNING *
            `, [req.user.id, title, type, shareToken]);

            res.status(201).json({ playlist: result.rows[0] });
        } catch (err) {
            console.error('Create playlist error:', err);
            res.status(500).json({ error: 'Failed to create playlist' });
        }
    });

    /**
     * GET /api/playlists/:id
     * Get playlist with tracks
     */
    router.get('/:id', optionalAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { token } = req.query;

            const playlistResult = await pool.query(
                'SELECT * FROM playlists WHERE id = $1',
                [id]
            );

            if (playlistResult.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            const playlist = playlistResult.rows[0];

            // Check access
            const isOwner = req.user && req.user.id === playlist.owner_id;
            const hasValidToken = token && token === playlist.share_token;
            const isPublic = playlist.is_public;

            if (!isOwner && !hasValidToken && !isPublic) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Get tracks with order
            const tracksResult = await pool.query(`
                SELECT t.id, t.title, t.status, t.type, t.cover_art_path,
                       t.current_version_id,
                       tv.duration_seconds,
                       pt.sort_order
                FROM playlist_tracks pt
                JOIN tracks t ON pt.track_id = t.id
                LEFT JOIN track_versions tv ON t.current_version_id = tv.id
                WHERE pt.playlist_id = $1
                ORDER BY pt.sort_order ASC
            `, [id]);

            if (!isOwner) {
                delete playlist.share_token;
            }

            res.json({ 
                playlist,
                tracks: tracksResult.rows,
                isOwner
            });
        } catch (err) {
            console.error('Get playlist error:', err);
            res.status(500).json({ error: 'Failed to get playlist' });
        }
    });

    /**
     * PUT /api/playlists/:id
     * Update playlist metadata
     */
    router.put('/:id', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { title, type, is_public } = req.body;

            // Verify ownership
            const existing = await pool.query(
                'SELECT owner_id FROM playlists WHERE id = $1',
                [id]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            if (existing.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const result = await pool.query(`
                UPDATE playlists 
                SET title = COALESCE($1, title),
                    type = COALESCE($2, type),
                    is_public = COALESCE($3, is_public)
                WHERE id = $4
                RETURNING *
            `, [title, type, is_public, id]);

            res.json({ playlist: result.rows[0] });
        } catch (err) {
            console.error('Update playlist error:', err);
            res.status(500).json({ error: 'Failed to update playlist' });
        }
    });

    /**
     * DELETE /api/playlists/:id
     * Delete playlist (not the tracks)
     */
    router.delete('/:id', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;

            // Verify ownership
            const existing = await pool.query(
                'SELECT owner_id FROM playlists WHERE id = $1',
                [id]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            if (existing.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            await pool.query('DELETE FROM playlists WHERE id = $1', [id]);

            res.json({ success: true });
        } catch (err) {
            console.error('Delete playlist error:', err);
            res.status(500).json({ error: 'Failed to delete playlist' });
        }
    });

    /**
     * POST /api/playlists/:id/tracks
     * Add a track to playlist
     */
    router.post('/:id/tracks', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { trackId } = req.body;

            if (!trackId) {
                return res.status(400).json({ error: 'trackId is required' });
            }

            // Verify playlist ownership
            const playlist = await pool.query(
                'SELECT owner_id FROM playlists WHERE id = $1',
                [id]
            );

            if (playlist.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            if (playlist.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Verify track exists and user owns it
            const track = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [trackId]
            );

            if (track.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (track.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'You can only add your own tracks' });
            }

            // Get next sort order
            const orderResult = await pool.query(
                'SELECT COALESCE(MAX(sort_order), -1) + 1 as next_order FROM playlist_tracks WHERE playlist_id = $1',
                [id]
            );

            await pool.query(`
                INSERT INTO playlist_tracks (playlist_id, track_id, sort_order)
                VALUES ($1, $2, $3)
                ON CONFLICT (playlist_id, track_id) DO NOTHING
            `, [id, trackId, orderResult.rows[0].next_order]);

            res.status(201).json({ success: true });
        } catch (err) {
            console.error('Add track to playlist error:', err);
            res.status(500).json({ error: 'Failed to add track' });
        }
    });

    /**
     * DELETE /api/playlists/:id/tracks/:trackId
     * Remove a track from playlist
     */
    router.delete('/:id/tracks/:trackId', requireAuth, async (req, res) => {
        try {
            const { id, trackId } = req.params;

            // Verify playlist ownership
            const playlist = await pool.query(
                'SELECT owner_id FROM playlists WHERE id = $1',
                [id]
            );

            if (playlist.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            if (playlist.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            await pool.query(
                'DELETE FROM playlist_tracks WHERE playlist_id = $1 AND track_id = $2',
                [id, trackId]
            );

            res.json({ success: true });
        } catch (err) {
            console.error('Remove track from playlist error:', err);
            res.status(500).json({ error: 'Failed to remove track' });
        }
    });

    /**
     * PUT /api/playlists/:id/reorder
     * Reorder tracks in playlist
     */
    router.put('/:id/reorder', requireAuth, async (req, res) => {
        const { id } = req.params;
        const { trackIds } = req.body;

        if (!Array.isArray(trackIds)) {
            return res.status(400).json({ error: 'trackIds must be an array' });
        }

        // Verify playlist ownership
        const playlist = await pool.query(
            'SELECT owner_id FROM playlists WHERE id = $1',
            [id]
        );

        if (playlist.rows.length === 0) {
            return res.status(404).json({ error: 'Playlist not found' });
        }

        if (playlist.rows[0].owner_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            for (let i = 0; i < trackIds.length; i++) {
                await client.query(
                    'UPDATE playlist_tracks SET sort_order = $1 WHERE playlist_id = $2 AND track_id = $3',
                    [i, id, trackIds[i]]
                );
            }

            await client.query('COMMIT');
            res.json({ success: true });
        } catch (e) {
            await client.query('ROLLBACK');
            console.error('Reorder error:', e);
            res.status(500).json({ error: e.message });
        } finally {
            client.release();
        }
    });

    /**
     * POST /api/playlists/:id/duplicate
     * Duplicate a playlist
     */
    router.post('/:id/duplicate', requireAuth, async (req, res) => {
        const client = await pool.connect();
        
        try {
            const { id } = req.params;

            // Get original playlist
            const original = await client.query(
                'SELECT * FROM playlists WHERE id = $1',
                [id]
            );

            if (original.rows.length === 0) {
                return res.status(404).json({ error: 'Playlist not found' });
            }

            // Only owner can duplicate
            if (original.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            await client.query('BEGIN');

            // Create new playlist
            const shareToken = uuidv4().replace(/-/g, '');
            const newPlaylist = await client.query(`
                INSERT INTO playlists (owner_id, title, type, share_token)
                VALUES ($1, $2, $3, $4)
                RETURNING *
            `, [req.user.id, `${original.rows[0].title} (Copy)`, original.rows[0].type, shareToken]);

            // Copy tracks
            await client.query(`
                INSERT INTO playlist_tracks (playlist_id, track_id, sort_order)
                SELECT $1, track_id, sort_order
                FROM playlist_tracks
                WHERE playlist_id = $2
            `, [newPlaylist.rows[0].id, id]);

            await client.query('COMMIT');

            res.status(201).json({ playlist: newPlaylist.rows[0] });
        } catch (err) {
            await client.query('ROLLBACK');
            console.error('Duplicate playlist error:', err);
            res.status(500).json({ error: 'Failed to duplicate playlist' });
        } finally {
            client.release();
        }
    });

    return router;
};
