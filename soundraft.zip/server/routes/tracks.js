const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { requireAuth, optionalAuth, checkShareAccess } = require('../middleware/auth');

const router = express.Router();

module.exports = function(pool, minioClient, BUCKET_NAME, upload) {
    
    /**
     * GET /api/tracks
     * List all tracks for authenticated user
     */
    router.get('/', requireAuth, async (req, res) => {
        try {
            const result = await pool.query(`
                SELECT t.*, 
                       tv.duration_seconds,
                       tv.version_number as current_version_number
                FROM tracks t
                LEFT JOIN track_versions tv ON t.current_version_id = tv.id
                WHERE t.owner_id = $1
                ORDER BY t.updated_at DESC
            `, [req.user.id]);

            res.json({ tracks: result.rows });
        } catch (err) {
            console.error('List tracks error:', err);
            res.status(500).json({ error: 'Failed to list tracks' });
        }
    });

    /**
     * POST /api/tracks
     * Create a new track
     */
    router.post('/', requireAuth, async (req, res) => {
        try {
            const { title, status = 'WIP', type = 'RELEASE' } = req.body;

            if (!title) {
                return res.status(400).json({ error: 'Title is required' });
            }

            // Generate share token
            const shareToken = uuidv4().replace(/-/g, '');

            const result = await pool.query(`
                INSERT INTO tracks (owner_id, title, status, type, share_token)
                VALUES ($1, $2, $3, $4, $5)
                RETURNING *
            `, [req.user.id, title, status, type, shareToken]);

            res.status(201).json({ track: result.rows[0] });
        } catch (err) {
            console.error('Create track error:', err);
            res.status(500).json({ error: 'Failed to create track' });
        }
    });

    /**
     * GET /api/tracks/:id
     * Get track details (with share token support)
     */
    router.get('/:id', optionalAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { token } = req.query;

            const result = await pool.query(`
                SELECT t.*, 
                       tv.duration_seconds,
                       tv.version_number as current_version_number,
                       tv.filename as current_filename
                FROM tracks t
                LEFT JOIN track_versions tv ON t.current_version_id = tv.id
                WHERE t.id = $1
            `, [id]);

            if (result.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            const track = result.rows[0];

            // Check access
            const isOwner = req.user && req.user.id === track.owner_id;
            const hasValidToken = token && token === track.share_token;
            const isPublic = track.release_status === 'PUBLIC';

            if (!isOwner && !hasValidToken && !isPublic) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Remove sensitive fields for non-owners
            if (!isOwner) {
                delete track.share_token;
            }

            res.json({ track, isOwner });
        } catch (err) {
            console.error('Get track error:', err);
            res.status(500).json({ error: 'Failed to get track' });
        }
    });

    /**
     * PUT /api/tracks/:id
     * Update track metadata
     */
    router.put('/:id', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { title, status, type, release_status } = req.body;

            // Verify ownership
            const existing = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [id]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (existing.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const result = await pool.query(`
                UPDATE tracks 
                SET title = COALESCE($1, title),
                    status = COALESCE($2, status),
                    type = COALESCE($3, type),
                    release_status = COALESCE($4, release_status),
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = $5
                RETURNING *
            `, [title, status, type, release_status, id]);

            res.json({ track: result.rows[0] });
        } catch (err) {
            console.error('Update track error:', err);
            res.status(500).json({ error: 'Failed to update track' });
        }
    });

    /**
     * DELETE /api/tracks/:id
     * Delete track and all versions
     */
    router.delete('/:id', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;

            // Verify ownership
            const existing = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [id]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (existing.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Get all versions to delete from storage
            const versions = await pool.query(
                'SELECT storage_key FROM track_versions WHERE track_id = $1',
                [id]
            );

            // Delete from MinIO
            for (const version of versions.rows) {
                try {
                    await minioClient.removeObject(BUCKET_NAME, version.storage_key);
                } catch (e) {
                    console.error('MinIO delete error:', e.message);
                }
            }

            // Delete from DB (cascades to versions, attachments)
            await pool.query('DELETE FROM tracks WHERE id = $1', [id]);

            res.json({ success: true });
        } catch (err) {
            console.error('Delete track error:', err);
            res.status(500).json({ error: 'Failed to delete track' });
        }
    });

    /**
     * GET /api/tracks/:id/versions
     * List all versions of a track
     */
    router.get('/:id/versions', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;

            // Verify ownership
            const track = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [id]
            );

            if (track.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (track.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const result = await pool.query(`
                SELECT id, version_number, filename, mime_type, size_bytes, duration_seconds, created_at
                FROM track_versions
                WHERE track_id = $1
                ORDER BY version_number DESC
            `, [id]);

            res.json({ versions: result.rows });
        } catch (err) {
            console.error('List versions error:', err);
            res.status(500).json({ error: 'Failed to list versions' });
        }
    });

    /**
     * POST /api/tracks/:id/versions
     * Upload a new version of a track
     */
    router.post('/:id/versions', requireAuth, upload.single('audio'), async (req, res) => {
        try {
            const { id } = req.params;

            if (!req.file) {
                return res.status(400).json({ error: 'No audio file provided' });
            }

            // Validate MIME type
            const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/x-wav'];
            if (!allowedTypes.includes(req.file.mimetype)) {
                return res.status(400).json({ error: 'Invalid file type. Only MP3 and WAV allowed.' });
            }

            // Verify ownership
            const track = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [id]
            );

            if (track.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (track.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Get next version number
            const versionResult = await pool.query(
                'SELECT COALESCE(MAX(version_number), 0) + 1 as next_version FROM track_versions WHERE track_id = $1',
                [id]
            );
            const versionNumber = versionResult.rows[0].next_version;

            // Generate storage key
            const fileExt = req.file.originalname.split('.').pop();
            const storageKey = `tracks/${id}/v${versionNumber}_${Date.now()}.${fileExt}`;

            // Upload to MinIO
            await minioClient.putObject(
                BUCKET_NAME,
                storageKey,
                req.file.buffer,
                req.file.size,
                { 'Content-Type': req.file.mimetype }
            );

            // TODO: Extract duration using ffprobe
            // For now, default to 0
            const durationSeconds = 0;

            // Create version record
            const result = await pool.query(`
                INSERT INTO track_versions (track_id, version_number, filename, storage_key, mime_type, size_bytes, duration_seconds)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING *
            `, [id, versionNumber, req.file.originalname, storageKey, req.file.mimetype, req.file.size, durationSeconds]);

            const newVersion = result.rows[0];

            // Update track's current version
            await pool.query(
                'UPDATE tracks SET current_version_id = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
                [newVersion.id, id]
            );

            res.status(201).json({ version: newVersion });
        } catch (err) {
            console.error('Upload version error:', err);
            res.status(500).json({ error: 'Failed to upload version' });
        }
    });

    /**
     * POST /api/tracks/:id/share
     * Generate or regenerate share token
     */
    router.post('/:id/share', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;
            const { makePublic } = req.body;

            // Verify ownership
            const existing = await pool.query(
                'SELECT owner_id FROM tracks WHERE id = $1',
                [id]
            );

            if (existing.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            if (existing.rows[0].owner_id !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Generate new share token
            const shareToken = uuidv4().replace(/-/g, '');
            
            const result = await pool.query(`
                UPDATE tracks 
                SET share_token = $1,
                    release_status = $2,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = $3
                RETURNING share_token, release_status
            `, [shareToken, makePublic ? 'PUBLIC' : 'PRIVATE', id]);

            res.json({ 
                shareToken: result.rows[0].share_token,
                releaseStatus: result.rows[0].release_status
            });
        } catch (err) {
            console.error('Share track error:', err);
            res.status(500).json({ error: 'Failed to generate share link' });
        }
    });

    return router;
};
