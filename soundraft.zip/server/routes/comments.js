const express = require('express');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

module.exports = function(pool) {
    
    /**
     * GET /api/comments/track/:trackId
     * List comments for a track
     */
    router.get('/track/:trackId', optionalAuth, async (req, res) => {
        try {
            const { trackId } = req.params;
            const { token } = req.query;

            // Check track exists and user has access
            const track = await pool.query(
                'SELECT owner_id, share_token, release_status FROM tracks WHERE id = $1',
                [trackId]
            );

            if (track.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            const trackData = track.rows[0];
            const isOwner = req.user && req.user.id === trackData.owner_id;
            const hasValidToken = token && token === trackData.share_token;
            const isPublic = trackData.release_status === 'PUBLIC';

            if (!isOwner && !hasValidToken && !isPublic) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // Get comments with user info
            const result = await pool.query(`
                SELECT c.id, c.body, c.audio_timestamp, c.created_at,
                       u.id as user_id, u.email as user_email
                FROM comments c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.track_id = $1
                ORDER BY c.audio_timestamp ASC NULLS LAST, c.created_at ASC
            `, [trackId]);

            // Mask emails for non-owners
            const comments = result.rows.map(comment => ({
                ...comment,
                user_email: isOwner ? comment.user_email : (comment.user_email ? 'User' : 'Anonymous')
            }));

            res.json({ comments });
        } catch (err) {
            console.error('List comments error:', err);
            res.status(500).json({ error: 'Failed to list comments' });
        }
    });

    /**
     * POST /api/comments/track/:trackId
     * Add a comment to a track
     */
    router.post('/track/:trackId', optionalAuth, async (req, res) => {
        try {
            const { trackId } = req.params;
            const { body, audioTimestamp, token } = req.body;

            if (!body || body.trim().length === 0) {
                return res.status(400).json({ error: 'Comment body is required' });
            }

            // Check track exists and user has access
            const track = await pool.query(
                'SELECT owner_id, share_token, release_status FROM tracks WHERE id = $1',
                [trackId]
            );

            if (track.rows.length === 0) {
                return res.status(404).json({ error: 'Track not found' });
            }

            const trackData = track.rows[0];
            const isOwner = req.user && req.user.id === trackData.owner_id;
            const hasValidToken = token && token === trackData.share_token;
            const isPublic = trackData.release_status === 'PUBLIC';

            // Must have some form of access
            if (!isOwner && !hasValidToken && !isPublic) {
                return res.status(403).json({ error: 'Access denied' });
            }

            // If not authenticated and not public, can't comment
            if (!req.user && !isPublic && !hasValidToken) {
                return res.status(401).json({ error: 'Authentication required to comment' });
            }

            const result = await pool.query(`
                INSERT INTO comments (user_id, track_id, body, audio_timestamp)
                VALUES ($1, $2, $3, $4)
                RETURNING id, body, audio_timestamp, created_at
            `, [req.user?.id || null, trackId, body.trim(), audioTimestamp || null]);

            const comment = result.rows[0];
            
            res.status(201).json({ 
                comment: {
                    ...comment,
                    user_email: req.user?.email || 'Anonymous'
                }
            });
        } catch (err) {
            console.error('Add comment error:', err);
            res.status(500).json({ error: 'Failed to add comment' });
        }
    });

    /**
     * DELETE /api/comments/:id
     * Delete a comment (owner of comment or track owner)
     */
    router.delete('/:id', requireAuth, async (req, res) => {
        try {
            const { id } = req.params;

            // Get comment with track info
            const result = await pool.query(`
                SELECT c.*, t.owner_id as track_owner_id
                FROM comments c
                JOIN tracks t ON c.track_id = t.id
                WHERE c.id = $1
            `, [id]);

            if (result.rows.length === 0) {
                return res.status(404).json({ error: 'Comment not found' });
            }

            const comment = result.rows[0];

            // Allow deletion by comment author or track owner
            const isCommentAuthor = comment.user_id === req.user.id;
            const isTrackOwner = comment.track_owner_id === req.user.id;

            if (!isCommentAuthor && !isTrackOwner) {
                return res.status(403).json({ error: 'Access denied' });
            }

            await pool.query('DELETE FROM comments WHERE id = $1', [id]);

            res.json({ success: true });
        } catch (err) {
            console.error('Delete comment error:', err);
            res.status(500).json({ error: 'Failed to delete comment' });
        }
    });

    return router;
};
